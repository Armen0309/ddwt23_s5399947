<?php
/**
 * Model
 *
 * Database-driven Webtechnology
 * Taught by Stijn Eikelboom
 * Based on code by Reinard van Dalen
 */

/* Enable error reporting */
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/**
 * Check if the route exists
 * @param string $route_uri URI to be matched
 * @param string $request_type Request method
 * @return bool
 *
 */
function new_route($route_uri, $request_type){
    $route_uri_expl = array_filter(explode('/', $route_uri));
    $current_path_expl = array_filter(explode('/',parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)));
    if ($route_uri_expl == $current_path_expl && $_SERVER['REQUEST_METHOD'] == strtoupper($request_type)) {
        return True;
    } else {
        return False;
    }
}

/**
 * Creates a new navigation array item using URL and active status
 * @param string $url The URL of the navigation item
 * @param bool $active Set the navigation item to active or inactive
 * @return array
 */
function na($url, $active){
    return [$url, $active];
}

/**
 * Creates filename to the template
 * @param string $template Filename of the template without extension
 * @return string
 */
function use_template($template){
    return sprintf("views/%s.php", $template);
}

/**
 * Creates breadcrumbs HTML code using given array
 * @param array $breadcrumbs Array with as Key the page name and as Value the corresponding URL
 * @return string HTML code that represents the breadcrumbs
 */
function get_breadcrumbs($breadcrumbs) {
    $breadcrumbs_exp = '<nav aria-label="breadcrumb">';
    $breadcrumbs_exp .= '<ol class="breadcrumb">';
    foreach ($breadcrumbs as $name => $info) {
        if ($info[1]){
            $breadcrumbs_exp .= '<li class="breadcrumb-item active" aria-current="page">'.$name.'</li>';
        } else {
            $breadcrumbs_exp .= '<li class="breadcrumb-item"><a href="'.$info[0].'">'.$name.'</a></li>';
        }
    }
    $breadcrumbs_exp .= '</ol>';
    $breadcrumbs_exp .= '</nav>';
    return $breadcrumbs_exp;
}

/**
 * Creates navigation bar HTML code using given array
 * @param array $navigation Array with as Key the page name and as Value the corresponding URL
 * @return string HTML code that represents the navigation bar
 */
function get_navigation($navigation){
    $navigation_exp = '<nav class="navbar navbar-expand-lg navbar-light bg-light">';
    $navigation_exp .= '<a class="navbar-brand">Series Overview</a>';
    $navigation_exp .= '<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">';
    $navigation_exp .= '<span class="navbar-toggler-icon"></span>';
    $navigation_exp .= '</button>';
    $navigation_exp .= '<div class="collapse navbar-collapse" id="navbarSupportedContent">';
    $navigation_exp .= '<ul class="navbar-nav mr-auto">';
    foreach ($navigation as $name => $info) {
        if ($info[1]){
            $navigation_exp .= '<li class="nav-item active">';
        } else {
            $navigation_exp .= '<li class="nav-item">';
        }
        $navigation_exp .= '<a class="nav-link" href="'.$info[0].'">'.$name.'</a>';

        $navigation_exp .= '</li>';
    }
    $navigation_exp .= '</ul>';
    $navigation_exp .= '</div>';
    $navigation_exp .= '</nav>';
    return $navigation_exp;
}

/**
 * Pretty Print Array
 * @param $input
 */
function p_print($input){
    echo '<pre>';
    print_r($input);
    echo '</pre>';
}

/**
 * Creates HTML alert code with information about the success or failure
 * @param array $feedback Associative array with keys type and message
 * @return string
 */
function get_error($feedback){
    return '
        <div class="alert alert-'.$feedback['type'].'" role="alert">
            '.$feedback['message'].'
        </div>';
}

/* function to connect database*/
function connect_db($host, $database, $username, $password) {
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

/* function returns number of series enlisted in database*/
function count_series($db) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM series");
    $stmt->execute();
    return $stmt->fetchColumn();
}

/* function returns associative array with all the series listed in the database*/
function get_series($db) {
    $stmt = $db->prepare("SELECT * FROM series");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
/* function returns a string with the HTML code representing the table with all the series*/
function get_series_table($series) {
    $table_html = '
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">Series</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>';
    foreach ($series as $serie) {
        $table_html .= '
            <tr>
                <th scope="row">'.htmlspecialchars($serie['name']).'</th>
                <td><a href="/DDWT23/week1/series/?series_id='.$serie['id'].'" role="button" class="btn btn-primary">More info</a></td>
            </tr>';
    }
    $table_html .= '
            </tbody>
        </table>';
    return $table_html;
}

/* function to add series */
function add_series($db, $post_data) {
    if (empty($post_data['name']) || empty($post_data['creator']) ||
        empty($post_data['seasons']) || empty($post_data['abstract'])) {
        return [
            'type' => 'danger',
            'message' => 'fill in all fields'
        ];
    }
    if (!is_numeric($post_data['seasons'])) {
        return [
            'type' => 'danger',
            'message' => 'has to be be numeric value'
        ];
    }
    $existing_series = get_series_by_name($db, $post_data['name']);
    if ($existing_series) {
        return [
            'type' => 'danger',
            'message' => 'already exists'
        ];
    }

    $stmt = $db->prepare("INSERT INTO series (series_title, series_creator, nbr_seasons, series_abstract)
                          VALUES (:title, :creator, :seasons, :abstract)");

    $stmt->bindParam(':title', $post_data['name']);
    $stmt->bindParam(':creator', $post_data['creator']);
    $stmt->bindParam(':seasons', $post_data['seasons']);
    $stmt->bindParam(':abstract', $post_data['abstract']);

    /* 6b. last 2 parts */
    try {
        $stmt->execute();
        return [
            'type' => 'success',
            'message' => 'Series was successfully added.'
        ];
    } catch (PDOException $e) {
        return [
            'type' => 'danger',
            'message' => 'Series wasn’t added. There was an error.' . $e->getMessage()
        ];
    }
}

/* function to get series info */
function get_series_info($db, $series_id) {
    $stmt = $db->prepare("SELECT * FROM series WHERE id = :series_id");
    $stmt->bindParam(':series_id', $series_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/* funtion to update series */
function update_series($pdo, $series_id, $name, $creator, $seasons, $abstract) {

    if (empty($name) || empty($creator) || empty($seasons) || empty($abstract)) {
        return [
            'type' => 'danger',
            'message' => 'All fields are required.'
        ];
    }

    if (!is_numeric($seasons)) {
        return [
            'type' => 'danger',
            'message' => 'Seasons must be a number.'
        ];
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM series WHERE name = :name AND id <> :id');
    $stmt->execute(['name' => $name, 'id' => $series_id]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        return [
            'type' => 'danger',
            'message' => 'A series with this name already exists.'
        ];
    }

    $stmt = $pdo->prepare('UPDATE series SET name = ?, creator = ?, seasons = ?, abstract = ? WHERE id = ?');
    $stmt->execute([$name, $creator, $seasons, $abstract, $series_id]);

    return [
        'type' => 'success',
        'message' => 'Series was successfully updated.'
    ];
}

/* function to remove series */
function remove_series($pdo, $series_id) {
    $stmt = $pdo->prepare('DELETE FROM series WHERE id = ?');
    $stmt->execute([$series_id]);


    if ($stmt->rowCount() > 0) {
        return [
            'type' => 'success',
            'message' => 'Series was successfully removed.'
        ];
    } else {
        return [
            'type' => 'danger',
            'message' => 'Series was not removed. There was an error.'
        ];
    }
}