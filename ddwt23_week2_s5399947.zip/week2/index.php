<?php
/**
 * Controller
 *
 * Database-driven Webtechnology
 * Taught by Stijn Eikelboom
 * Based on code by Reinard van Dalen
 */

include 'model.php';

/* Connect to DB */
$db = connect_db('localhost', 'ddwt23_week2', 'ddwt23','ddwt23');

# number active series
$nbr_series = count_series($db);

# number active users
$nbr_users = count_users($db);

$right_column = use_template('cards');

/* Landing page */
if (new_route('/DDWT23/week2/', 'get')) {

    /* Page info */
    $page_title = 'Home';
    $breadcrumbs = get_breadcrumbs([
        'DDWT23' => na('/DDWT23/', False),
        'Week 2' => na('/DDWT23/week2/', False),
        'Home' => na('/DDWT23/week2/', True)
    ]);
    $navigation = get_navigation([
        'Home' => na('/DDWT23/week2/', True),
        'Overview' => na('/DDWT23/week2/overview/', False),
        'Add Series' => na('/DDWT23/week2/add/', False),
        'My Account' => na('/DDWT23/week2/myaccount/', False),
        'Registration' => na('/DDWT23/week2/register/', False)
    ]);

    /* Page content */
    $page_subtitle = 'The online platform to list your favorite series';
    $page_content = 'On Series Overview you can list your favorite series. You can see the favorite series of all Series Overview users. By sharing your favorite series, you can get inspired by others and explore new series.';

    /* Choose Template */
    include use_template('main');
}

/* Overview page */
elseif (new_route('/DDWT23/week2/overview/', 'get')) {
    /* Get Number of Series */

    /* Page info */
    $page_title = 'Overview';
    $breadcrumbs = get_breadcrumbs([
        'DDWT23' => na('/DDWT23/', False),
        'Week 2' => na('/DDWT23/week2/', False),
        'Overview' => na('/DDWT23/week2/overview', True)
    ]);
    $navigation = get_navigation([
        'Home' => na('/DDWT23/week2/', False),
        'Overview' => na('/DDWT23/week2/overview', True),
        'Add Series' => na('/DDWT23/week2/add/', False),
        'My Account' => na('/DDWT23/week2/myaccount/', False),
        'Registration' => na('/DDWT23/week2/register/', False)
    ]);

    /* Page content */
    $page_subtitle = 'The overview of all series';
    $page_content = 'Here you find all series listed on Series Overview.';
    $left_content = get_series_table(get_series($db));

    /* Choose Template */
    include use_template('main');
}

/* Single series */
elseif (new_route('/DDWT23/week2/series/', 'get')) {
    /* Get Number of Series */

    /* Get series from db */
    $series_id = $_GET['series_id'];
    $series_info = get_series_info($db, $series_id);

    # series added by user
    $added_by = get_added_by_user($db, $series_id);

    /* Page info */
    $page_title = $series_info['name'];
    $breadcrumbs = get_breadcrumbs([
        'DDWT23' => na('/DDWT23/', False),
        'Week 2' => na('/DDWT23/week2/', False),
        'Overview' => na('/DDWT23/week2/overview/', False),
        $series_info['name'] => na('/DDWT23/week2/series/?series_id='.$series_id, True)
    ]);
    $navigation = get_navigation([
        'Home' => na('/DDWT23/week2/', False),
        'Overview' => na('/DDWT23/week2/overview', True),
        'Add series' => na('/DDWT23/week2/add/', False),
        'My Account' => na('/DDWT23/week2/myaccount/', False),
        'Registration' => na('/DDWT23/week2/register/', False)
    ]);

    /* Page content */
    $page_subtitle = sprintf("Information about %s", $series_info['name']);
    $page_content = $series_info['abstract'];
    $nbr_seasons = $series_info['seasons'];
    $creators = $series_info['creator'];

    /* Choose Template */
    include use_template('series');
}

/* Add series GET */
elseif (new_route('/DDWT23/week2/add/', 'get')) {

    #check if user loggedin
    $display_buttons = check_login();

    # checks if error message present in get
    if (isset($_GET['error_msg'])) {

        # decode json
        $feedback = json_decode(urldecode($_GET['error_msg']), true);

        $error_msg_html = get_error($feedback);
    } else {
        # if no error message --> empty string
        $error_msg_html = '';
    }

    // Include template with error message HTML
    include use_template('new');
}


/* Add series POST */
elseif (new_route('/DDWT23/week2/add/', 'post')) {
    # add series to database
    $feedback = add_series($db, $_POST);

    # making error message
    $error_msg = urlencode(json_encode($feedback));

    # redirect to add route with error_msg
    redirect('/DDWT23/week2/add/?error_msg=' . $error_msg);
}


/* Edit series GET */
elseif (new_route('/DDWT23/week2/edit/', 'get')) {

    /* Get series info from db */
    $series_id = $_GET['series_id'];
    $series_info = get_series_info($db, $series_id);

    /* Page info */
    $page_title = 'Edit Series';
    $breadcrumbs = get_breadcrumbs([
        'DDWT23' => na('/DDWT23/', False),
        'Week 2' => na('/DDWT23/week2/', False),
        sprintf("Edit Series %s", $series_info['name']) => na('/DDWT23/week2/new/', True)
    ]);
    $navigation = get_navigation([
        'Home' => na('/DDWT23/week2/', False),
        'Overview' => na('/DDWT23/week2/overview', False),
        'Add Series' => na('/DDWT23/week2/add/', False),
        'My Account' => na('/DDWT23/week2/myaccount/', False),
        'Registration' => na('/DDWT23/week2/register/', False)
    ]);

    /* Page content */
    $page_subtitle = sprintf('Edit %s', $series_info['name']);
    $page_content = 'Edit the series below.';
    $submit_btn = 'Edit Series';
    $form_action = '/DDWT23/week2/edit/';

    /* Choose Template */
    include use_template('new');
}

/* Edit series POST */
elseif (new_route('/DDWT23/week2/edit/', 'post')) {

    # update series in db
    $feedback = update_series($db, $_POST);

    # series info from db
    $series_id = $_POST['series_id'];

    # redirect to series with series_id + error message
    $error_msg = urlencode(json_encode($feedback));
    redirect('/DDWT23/week2/series/?series_id='.$series_id.'&error_msg='.$error_msg);
}

/* Remove series */
elseif (new_route('/DDWT23/week2/remove/', 'post')) {

    # remove series in db
    $series_id = $_POST['series_id'];
    $feedback = remove_series($db, $series_id);

    # redirect to overview/error message
    $error_msg = urlencode(json_encode($feedback));
    redirect('/DDWT23/week2/overview/?error_msg='.$error_msg);
}



/* user authentication routes */


/* myaccount GET route */
elseif (new_route('/DDWT23/week2/myaccount/', 'get')) {
    # checks if user logged in
    if (!check_login()) {
        redirect('/DDWT23/week2/login/');
    }

    # get username from db
    $user_id = $_SESSION['user_id'];
    $user_data = get_user_data($db, $user_id);
    $username = $user_data['username'];

    /* Page info */
    $page_title = 'My Account';
    $breadcrumbs = get_breadcrumbs([
        'DDWT23' => na('/DDWT23/', False),
        'Week 2' => na('/DDWT23/week2/', False),
        'My Account' => na('/DDWT23/week2/myaccount/', True)
    ]);
    $navigation = get_navigation([
        'Home' => na('/DDWT23/week2/', False),
        'Overview' => na('/DDWT23/week2/overview/', False),
        'Add Series' => na('/DDWT23/week2/add/', False),
        'My Account' => na('/DDWT23/week2/myaccount/', True),
        'Registration' => na('/DDWT23/week2/register/', False)
    ]);

    /* Page content */
    $page_subtitle = 'Welcome, ' . $username;
    $page_content = 'Here you can view and manage your account details.';

    /* Choose Template */
    include use_template('account');
}

/* register GET route */
elseif (new_route('/DDWT23/week2/register/', 'get')) {

    if (!check_login()) {
        redirect('/DDWT23/week2/login/');
    }

    /* Page info */
    $page_title = 'Register';
    $breadcrumbs = get_breadcrumbs([
        'DDWT23' => na('/DDWT23/', False),
        'Week 2' => na('/DDWT23/week2/', False),
        'Register' => na('/DDWT23/week2/register/', True)
    ]);
    $navigation = get_navigation([
        'Home' => na('/DDWT23/week2/', False),
        'Overview' => na('/DDWT23/week2/overview/', False),
        'Add Series' => na('/DDWT23/week2/add/', False),
        'My Account' => na('/DDWT23/week2/myaccount/', False),
        'Registration' => na('/DDWT23/week2/register/', True)
    ]);

    /* Page content */
    $error_msg = "Error sorry";

    /* Choose Template */
    include use_template('register');
}

/* register POST route */
elseif (new_route('/DDWT23/week2/register/', 'post')) {

    if (!check_login()) {
        redirect('/DDWT23/week2/login/');
    }

    # processing form data and get feedback
    $feedback = register_user($db, $_POST);

    # looks if registrating went well
    if ($feedback['type'] == 'success') {
        redirect('/DDWT23/week2/login/');
    } else {
        /* Page info */
        $page_title = 'Register';
        $breadcrumbs = get_breadcrumbs([
            'DDWT23' => na('/DDWT23/', False),
            'Week 2' => na('/DDWT23/week2/', False),
            'Register' => na('/DDWT23/week2/register/', True)
        ]);
        $navigation = get_navigation([
            'Home' => na('/DDWT23/week2/', False),
            'Overview' => na('/DDWT23/week2/overview/', False),
            'Add Series' => na('/DDWT23/week2/add/', False),
            'My Account' => na('/DDWT23/week2/myaccount/', False),
            'Registration' => na('/DDWT23/week2/register/', True)
        ]);

        /* Page content */
        $error_msg = $feedback['message'];

        /* Choose Template */
        include use_template('register');
    }
}

/* login GET route*/
elseif (new_route('/DDWT23/week2/login/', 'get')) {

    # goes to myaccount if logged in
    if (check_login()) {
        redirect('/DDWT23/week2/myaccount/');
    }
    /* Page info */
    $page_title = 'Login';
    $breadcrumbs = get_breadcrumbs([
        'DDWT23' => na('/DDWT23/', False),
        'Week 2' => na('/DDWT23/week2/', False),
        'Login' => na('/DDWT23/week2/login/', True)
    ]);
    $navigation = get_navigation([
        'Home' => na('/DDWT23/week2/', False),
        'Overview' => na('/DDWT23/week2/overview/', False),
        'Add Series' => na('/DDWT23/week2/add/', False),
        'My Account' => na('/DDWT23/week2/myaccount/', False),
        'Registration' => na('/DDWT23/week2/register/', False)
    ]);

    /* Page content */
    $error_msg = "error";

    /* Choose Template */
    include use_template('login');
}

/* login POST route */
elseif (new_route('/DDWT23/week2/login/', 'post')) {

    if (!check_login()) {
        redirect('/DDWT23/week2/login/');
    }


    # process login data and get feedback
    $feedback = login_user($db, $_POST);
    $error_msg_login = get_error($feedback);

    # redirect to myaccount after successful login
    if (!$error_msg_login) {
        redirect('/DDWT23/week2/myaccount/');
    } else {
        /* Page info */
        $page_title = 'Login';
        $breadcrumbs = get_breadcrumbs([
            'DDWT23' => na('/DDWT23/', False),
            'Week 2' => na('/DDWT23/week2/', False),
            'Login' => na('/DDWT23/week2/login/', True)
        ]);
        $navigation = get_navigation([
            'Home' => na('/DDWT23/week2/', False),
            'Overview' => na('/DDWT23/week2/overview/', False),
            'Add Series' => na('/DDWT23/week2/add/', False),
            'My Account' => na('/DDWT23/week2/myaccount/', False),
            'Registration' => na('/DDWT23/week2/register/', False)
        ]);

        /* Page content */
        $error_msg = $error_msg_login;

        /* Choose Template */
        include use_template('login');
    }
}

/* logout GET route */
elseif (new_route('/DDWT23/week2/logout/', 'get')) {
    #logout user
    $feedback = logout_user();

    # redirect to landing page + feedback message
    redirect('/DDWT23/week2/', $feedback);
}

else {
    http_response_code(404);
    echo '404 Not Found';
}


