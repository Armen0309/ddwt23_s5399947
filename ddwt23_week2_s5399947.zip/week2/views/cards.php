<!-- Series count -->
<div class="card">
    <div class="card-header">
        Series
    </div>
    <div class="card-body">
        <p class="count">Series overview already has</p>
        <h2><?= $nbr_series ?></h2>
        <p>series listed</p>
        <a href="/DDWT23/week2/add/" class="btn btn-primary">List yours</a>
    </div>
</div>

# user count
<div class="card">
    <div class="card-header">
        Users
    </div>
    <div class="card-body">
        <p class="count">Series overview has</p>
        <h2><?= $nbr_users ?></h2>
        <p>active users</p>
    </div>
</div>
